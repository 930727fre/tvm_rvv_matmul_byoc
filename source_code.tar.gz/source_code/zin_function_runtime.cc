/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*!
 * \file src/runtime/contrib/zin_function/zin_function_runtime.cc
 * \brief JSON runtime implementation for zin_function.
 */

#include <dmlc/parameter.h>
#include <tvm/runtime/ndarray.h>
#include <tvm/runtime/registry.h>

#include <fstream>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "../../file_utils.h"
#include "../json/json_node.h"
#include "../json/json_runtime.h"

// user add
#include<stdio.h>
#include<dlfcn.h>
#include<stdlib.h>
#include<iostream>

namespace tvm {
namespace runtime {
namespace contrib {

using namespace tvm::runtime::json;

class zin_function_Runtime : public JSONRuntimeBase {
 public:
  /*!
   * \brief The zin_function runtime module. Deserialize the provided functions
   * on creation and store in the layer cache.
   *
   * \param symbol_name The name of the function.
   * \param graph_json serialized JSON representation of a sub-graph.
   * \param const_names The names of each constant in the sub-graph.
   */
  explicit zin_function_Runtime(const std::string& symbol_name, const std::string& graph_json,
                           const Array<String>& const_names)
      : JSONRuntimeBase(symbol_name, graph_json, const_names) {}

  /*!
   * \brief The type key of the module.
   *
   * \return module type key.
   */
  const char* type_key() const final { return "zin_function"; }

  /*!
   * \brief Initialize runtime. Create zin_function layer from JSON
   * representation.
   *
   * \param consts The constant params from compiled model.
   */
  void Init(const Array<NDArray>& consts) override {
    ICHECK_EQ(consts.size(), const_idx_.size())
        << "The number of input constants must match the number of required.";
    SetupConstants(consts);
  }

  ~zin_function_Runtime() override {
    VLOG(1) << "Destroying zin_function runtime";
    VLOG(1) << "Destroyed zin_function runtime";
  }

  /*! \brief Run inference using built engine. */
  void Run() override {

    arg_arr.clear();
    type_arr.clear();
    buffer_arr.clear();   

    for(size_t i=0; i<nodes_.size(); i++){
      
      // shape
      auto OpShape = nodes_[i].GetOpShape()[0];
      int64_t node_arg = 1;
      for(size_t j=0; j<OpShape.size(); j++)
        node_arg *= OpShape[j];
      arg_arr.push_back(node_arg);

      // dtype
      auto tmp = nodes_[i].GetOpDataType();
      auto node_type = tmp[0].code;
      auto node_type_byte = tmp[0].bits/8;
      type_arr.push_back({node_type, node_type_byte});


      auto buffer = (float*)malloc(node_arg * node_type_byte);
      buffer_arr.push_back(buffer);
    }


    for (size_t i = 0; i < input_nodes_.size(); ++i) {
      auto nid = input_nodes_[i];
      if (nodes_[nid].GetOpType() == "input") {
        memcpy(buffer_arr[nid], data_entry_[nid]->data, arg_arr[nid] * type_arr[nid].second);
      }
    }

    for (size_t i = 0; i < outputs_.size(); ++i) {
      auto tmp = outputs_[i];
      auto nid = tmp.id_;
      memcpy(buffer_arr[nid], data_entry_[nid]->data, arg_arr[nid] * type_arr[nid].second);
    }

    for(size_t i=0; i<nodes_.size(); i++){
      auto input = nodes_[i].GetInputs();
      std::cout << "node: " << i << std::endl;
      std::cout << "\top_type: " << nodes_[i].GetOpType() << std::endl;
      std::cout << "\tname:    " << nodes_[i].GetOpName() << std::endl;
      for(size_t j=0; j<input.size(); j++){
        std::cout << "\tinput " << j << " : " << input[j].id_ << std::endl;
      }
    }

    for(int i=0; i<data_entry_[0]->ndim; i++)
      std::cout << "shape " << i << " : " << *(data_entry_[0]->shape+i) << std::endl;
    
    for(size_t nid=0; nid<nodes_.size(); nid++){
      if(nodes_[nid].GetOpType() == "kernel"){
        if(nodes_[nid].GetOpName() == "zin_function.add")
          zin_function_add(nid);
        // 後續增加其他 OP
        else;
      }
    }

    for (size_t i = 0; i < outputs_.size(); ++i) {
      auto tmp = outputs_[i];
      auto nid = tmp.id_;
      memcpy(data_entry_[nid]->data, buffer_arr[nid], arg_arr[nid] * type_arr[nid].second);
    }
  }

 private:

  void zin_function_add(size_t idx){
    // 之後可以改成在 build TVM 環境時就連結到 .so 檔，不然每個 add 都要導入一次 .so 檔
    void *handle = dlopen("/home/zin/tvm_code/test_BYOC/libadd_c.so", RTLD_LAZY);
    if(!handle)
      printf("open lib error\n");

    typedef void (*add_t)(float*, float*, float*, int);
    add_t add = (add_t)dlsym(handle, "add");

    if(!add){
      printf("use function error\n");
      dlclose(handle);
    }
    
    //if(data_entry_[0]->dtype.code == 0)
    //  typedef int TYPE;
    //else if(data_entry_[0]->dtype.code == 2)
    //  typedef float TYPE;
    //else;
    
    typedef _Float32 TYPE;

    /*
    int size = (data_entry_[0]->dtype.bits/8);
    TYPE* out = (TYPE*)malloc(arg * size);*/

    // inputs 
    std::vector<TYPE*> input_arr;
    auto inputs = nodes_[idx].GetInputs();
    for (size_t i = 0; i < inputs.size(); ++i) {
      auto nid = inputs[i].id_;
      input_arr.push_back((TYPE*)(buffer_arr[nid]));
    }
    auto out = (TYPE*)(buffer_arr[idx]);

    /*
    for (size_t i = 0; i < input_nodes_.size(); ++i) {
      auto nid = input_nodes_[i];
      if (nodes_[nid].GetOpType() == "input") {
        TYPE* tmp = (TYPE*)malloc(arg * size);
        memcpy(tmp, data_entry_[nid]->data, arg * size);
        input_arr.push_back(tmp);
      }
    }*/

    add(input_arr[0], input_arr[1], out, arg_arr[idx]);

    // outputs 
    /*
    for (size_t i = 0; i < outputs_.size(); ++i) {
      uint32_t eid = EntryID(outputs_[i]);
      memcpy(data_entry_[eid]->data, out, arg * size);
    }*/

    //free(out);
    dlclose(handle);
  }

  std::vector<int64_t> arg_arr;
  std::vector<std::pair<uint8_t, uint8_t>> type_arr;
  std::vector<void*> buffer_arr;
};

runtime::Module zinfunctionRuntimeCreate(const String& symbol_name, const String& graph_json,
                                      const Array<String>& const_names) {
  auto n = make_object<zin_function_Runtime>(symbol_name, graph_json, const_names);
  return runtime::Module(n);
}

TVM_REGISTER_GLOBAL("runtime.zin_function_runtime_create").set_body_typed(zinfunctionRuntimeCreate);

TVM_REGISTER_GLOBAL("runtime.module.loadbinary_zin_function")
    .set_body_typed(JSONRuntimeBase::LoadFromBinary<zin_function_Runtime>);

}  // namespace contrib
}  // namespace runtime
}  // namespace tvm
