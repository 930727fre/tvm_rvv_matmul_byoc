import tvm
from tvm import relax
from tvm.script.parser import relax as R
import numpy as np
# Define an example IRModule
@tvm.script.ir_module
class InputModule:
    @R.function
    def main(
        x: R.Tensor((16, 16), "float32"), 
        y: R.Tensor((16, 16), "float32")
    ) -> R.Tensor((16, 16), "float32"):
        with R.dataflow():
            z1 = R.add(x, y)
            z2 = R.add(z1, y)
            z3 = R.add(z2, x)
            z4 = R.multiply(z3, x)
            z5 = R.add(z4, x)
            z6 = R.add(z5, y)
            R.output(z6)
        return z6

mod = InputModule

from tvm.relax.dpl import is_op, wildcard

#patterns = [("zin_function.add", is_op("relax.add")(wildcard(), wildcard())), ("zin_function.multiply", is_op("relax.multiply")(wildcard(), wildcard()))]
patterns = [("zin_function.add", is_op("relax.add")(wildcard(), wildcard()))]
#patterns = [("cutlass.multiply", is_op("relax.multiply")(wildcard(), wildcard()))]

#mod = relax.transform.FuseOpsByPattern(patterns, annotate_codegen=True)(mod)
mod = relax.transform.FuseOpsByPattern(patterns, bind_constants=False)(mod)
#mod.show()

mod = relax.transform.MergeCompositeFunctions()(mod)
#mod.show()

mod = relax.transform.RunCodegen()(mod)
#mod.show()
#mod.show(show_meta=True)

#transform.LegalizeOps(

#from tvm._ffi import get_global_func

#print(get_global_func("runtime.zin_function_runtime_create"))

# Produced runtime module will be attached in the IRModule attribute.
#print(f"external runtime module: {mod.attrs['external_mods']}")

# Check if output IRModule is well-formed. 
assert relax.analysis.well_formed(mod)

# Define your target hardware and device.
target= tvm.target.Target("c")
dev = tvm.cpu()

# Prepare inputs.
np0 = np.random.rand(16, 16).astype(np.float32)
np1 = np.random.rand(16, 16).astype(np.float32)
data0 = tvm.nd.array(np0, dev)
data1 = tvm.nd.array(np1, dev)
inputs = [data0, data1]

z1 = np.add(np0, np1)
z2 = np.add(z1, np1)
z3 = np.add(z2, np0)
z4 = np.multiply(z3, np0)
z5 = np.add(z4, np0)
expected = np.add(z5, np1)

# Build and prepare VM. 
ex = relax.build(mod, target, params={})
vm = relax.VirtualMachine(ex, dev)

# Run VM. 
out = vm["main"](*inputs)

import tvm.testing
tvm.testing.assert_allclose(out.numpy(), expected, rtol=1e-6, atol=1e-6)
